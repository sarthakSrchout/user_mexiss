<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class order_overview extends Model
{
    protected $primaryKey="order_overw_id";
    protected $table="order_overview";
    protected $guarded=[];
}
