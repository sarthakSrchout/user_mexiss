<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductTechnicalData extends Model
{
    protected $table = 'product_technical_data';

    use HasFactory;
}
