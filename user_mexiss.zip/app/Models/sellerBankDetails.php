<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sellerBankDetails extends Model
{
    protected $primaryKey="sellar_bank_id";
    protected $table="sellar_bank";
    protected $guarded=[];
}
