<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class customeAttribute extends Model
{
    protected $primaryKey="custome_attribute_id";
    protected $table="custome_attribute";
    protected $guarded=[];
}
