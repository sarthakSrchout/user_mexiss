<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class productHighlights extends Model
{
    protected $primaryKey="pd_high_id ";
    protected $table="product_highlights";
    protected $guarded=[];
}
