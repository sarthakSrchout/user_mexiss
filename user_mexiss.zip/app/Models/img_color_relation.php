<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class img_color_relation extends Model
{
    protected $primaryKey="img_col_rel_id";
    protected $table="img_color_relation";
    protected $guarded=[];
}
